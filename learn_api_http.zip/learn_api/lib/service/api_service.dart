import 'dart:convert';
import 'package:learn_api/data/Article.dart';
import 'package:http/http.dart' as http;

class ArticleService {
  static const String _baseUrl = "https://newsapi.org/v2/";
  static const String _apiKey = "50726db323da449db7b94b4f4e47b376";
  static const String _country = "id";
  static const String _category = "business";

  Future<ArticlesResult> topHeadlines() async {
    final response = await http.get(Uri.parse("${_baseUrl}top-headlines?country=$_country&category=$_category&apiKey=$_apiKey"));
    if (response.statusCode == 200) {
      return ArticlesResult.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load top headlines');
    }
  }
}