// To parse this JSON data, do
//
//     final articleResult = articleResultFromJson(jsonString);

import 'dart:convert';

ArticleResult articleResultFromJson(String str) => ArticleResult.fromJson(json.decode(str));

class ArticleResult {
  ArticleResult({
    required this.status,
    required this.totalResults,
    required this.articles,
  });

  String status;
  int totalResults;
  List<Article> articles;

  factory ArticleResult.fromJson(Map<String, dynamic> json) => ArticleResult(
    status: json["status"],
    totalResults: json["totalResults"],
    articles: List<Article>.from(json["articles"].map((x) => Article.fromJson(x))
        .where((article) =>
          article.author != null &&
          article.urlToImage != null &&
          article.publishedAt != null &&
          article.content != null
      )
    ),
  );

}

class Article {
  Article({
    required this.author,
    required this.title,
    required this.description,
    required this.urlToImage,
    required this.publishedAt,
    required this.content,
  });

  String author;
  String title;
  String description;
  String urlToImage;
  DateTime publishedAt;
  String content;

  factory Article.fromJson(Map<String, dynamic> json) => Article(
    author: json["author"],
    title: json["title"],
    description: json["description"],
    urlToImage: json["urlToImage"],
    publishedAt: DateTime.parse(json["publishedAt"]),
    content: json["content"],
  );
}

