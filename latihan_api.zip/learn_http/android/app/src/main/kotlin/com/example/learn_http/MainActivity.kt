package com.example.learn_http

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
