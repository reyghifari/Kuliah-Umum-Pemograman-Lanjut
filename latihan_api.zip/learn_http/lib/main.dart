import 'package:flutter/material.dart';
import 'package:learn_http/data/article.dart';
import 'package:learn_http/service/api_service.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ArticleListPage(),
    );
  }
}

class ArticleListPage extends StatefulWidget {
  const ArticleListPage({Key? key}) : super(key: key);

  @override
  State<ArticleListPage> createState() => _ArticleListPageState();
}

class _ArticleListPageState extends State<ArticleListPage> {
  late Future<ArticleResult> _article;

  @override
  void initState() {
    super.initState();
    _article = ApiService().topHeadlines();
  }

  @override
  Widget build(BuildContext context ) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Get Data Api"),
      ),
      body: FutureBuilder(
        future: _article,
        builder: (context, AsyncSnapshot<ArticleResult> snapshot){
          var state = snapshot.connectionState;
          if(state != ConnectionState.done){
            return const Center(
              child: CircularProgressIndicator(),
            );
          }else{
            if(snapshot.hasData){
              return ListView.builder(
                itemCount: snapshot.data?.articles.length,
                itemBuilder: (context, index){
                  var article  = snapshot.data?.articles[index];
                  return InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) {
                        return DetailScreen(article: article);
                      }));
                    },
                    child: Card(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                              flex: 1,
                              child: Image.network(article!.urlToImage)),
                          Expanded(
                            flex: 2,
                            child: Padding(
                              padding:const EdgeInsets.all(8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Text(
                                    article.title,
                                    style: const TextStyle(fontSize: 16.0),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Text(article.author),
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  );
                },
              );
            }else if(snapshot.hasError){
              return Center(
                child: Material(
                  child: Text(snapshot.error.toString()),
                ),
              );
            }else{
              return const Material(child: Text(""),);
            }
          }
        },
      ),
    );
  }
}

class DetailScreen extends StatelessWidget{
  final Article article;

  const DetailScreen({Key? key, required this.article}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: SafeArea(
          child:Scaffold(
            body:Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Image.network(article.urlToImage),
                    IconButton(icon: const Icon(Icons.arrow_back), onPressed: () {
                      Navigator.pop(context);
                    })
                  ],
                ),
                Container(
                  margin:const EdgeInsets.only(top:10),
                  child: Text(
                      article.title,
                      style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                Container(
                  padding: const EdgeInsets.all(16.0),
                  child:  Center(
                    child:Text(
                        article.content ,
                        style: TextStyle(fontSize: 14), textAlign: TextAlign.center),
                  ),
                ),
              ],
            ),
          ),
        )
    );
  }
}


