import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        color: Colors.red,
        padding: const EdgeInsets.all(10.0),
            child: Container(
          color: Colors.greenAccent,
              height: 100,
              width: 100,
      ),
      ),
    );
  }
}