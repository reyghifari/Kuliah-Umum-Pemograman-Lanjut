import 'package:flutter/material.dart';
import 'package:learn_flutter_fundamental/tourism_place.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wisata Bandung',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MainScreen(),
    );
  }
}


class MainScreen extends StatelessWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context ) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Wisata Bandung"),
      ),
      body: ListView.builder(
        itemBuilder: (context, index){
          final TourismPlace place = tourismPlaceList[index];
          return InkWell(
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return SecondScreen(place: place);
              }));
            },
            child: Card(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                      flex: 1,
                      child: Image.asset(place.imageAsset)),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding:const EdgeInsets.all(8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Text(
                            place.name,
                            style: const TextStyle(fontSize: 16.0),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Text(place.location),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        },
        itemCount: tourismPlaceList.length,
      ),
    );
  }
}

class SecondScreen extends StatelessWidget{

  final TourismPlace place;

  const SecondScreen({Key? key, required this.place}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: SafeArea(
          child:Scaffold(
            body:Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Image.asset(place.imageAsset),
                    IconButton(icon: const Icon(Icons.arrow_back), onPressed: () {
                      Navigator.pop(context);
                    })
                  ],
                ),
                Container(
                  margin:const EdgeInsets.only(top:10),
                  child: Text(
                      place.name,
                      style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          Icon(Icons.date_range),
                          Text(
                              place.openDays,
                          )
                        ],
                      ),
                      Column(
                        children: <Widget>[
                          Icon(Icons.timelapse),
                          Text(
                            place.openTime
                          )
                        ],
                      ),
                      Column(
                        children: <Widget>[
                          Icon(Icons.money),
                          Text(
                            place.ticketPrice
                          )
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(16.0),
                  child:  Center(
                    child:Text(
                           place.description ,
                        style: TextStyle(fontSize: 14), textAlign: TextAlign.center),
                  ),
                ),
                SizedBox(
                  height: 150,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: place.imageUrls.map((url){
                      return Padding(
                          padding: EdgeInsets.all(4),
                        child: ClipRect(
                          child: Image.network(url),
                        )
                      );
                    }).toList(),
                  ) ,
                )
              ],
            ),
            floatingActionButton: FloatingActionButton(
              child: const Icon(Icons.add),
              onPressed: (){},
            ),
          ),
        )
    );
  }
}





