//50726db323da449db7b94b4f4e47b376
// To parse this JSON data, do
//
//     final news = newsFromJson(jsonString);

import 'dart:convert';

class ArticlesResult {
ArticlesResult({
  required this.status,
  required this.totalResults,
  required this.articles,
});

final String status;
final int totalResults;
final List<Article> articles;

factory ArticlesResult.fromJson(Map<String, dynamic> json) => ArticlesResult(
status: json["status"],
totalResults: json["totalResults"],
articles: List<Article>.from(
json["articles"].map((x) => Article.fromJson(x))),
);
}

class Article {
  Article({
    required this.author,
    required this.title,
    required this.description,
    required this.url,
    required this.urlToImage,
    required this.publishedAt,
    required this.content,
  });

  String? author;
  String title;
  String? description;
  String url;
  String? urlToImage;
  DateTime? publishedAt;
  String? content;

  factory Article.fromJson(Map<String, dynamic> json) => Article(
    author: json["author"],
    title: json["title"],
    description: json["description"],
    url: json["url"],
    urlToImage: json["urlToImage"],
    publishedAt: DateTime.parse(json["publishedAt"]),
    content: json["content"],
  );
}

