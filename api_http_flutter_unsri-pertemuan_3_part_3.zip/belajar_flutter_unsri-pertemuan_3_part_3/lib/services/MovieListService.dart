import 'package:movie/models/list_movie.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class MovieService {

  Future<ListMovie> topHeadlines() async {
    final response = await http.get(Uri.parse("https://api.themoviedb.org/3/movie/top_rated?api_key=ad70b1a0982af1b93f36caa498f9bf91&page=1"));
    if (response.statusCode == 200) {
      return ListMovie.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load top headlines');
    }
  }

  Future<PopularResults> topPopular() async {
    final response = await http.get(Uri.parse("https://api.themoviedb.org/3/movie/popular?api_key=ad70b1a0982af1b93f36caa498f9bf91&page=1"));
    if (response.statusCode == 200) {
      return PopularResults.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load top headlines');
    }
  }
}