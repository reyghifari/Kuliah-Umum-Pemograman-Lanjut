import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const Scaffold(
        body: FirstScreenFlutter2(),
      ),
    );
  }
}


class secondRoute extends StatelessWidget {
  const secondRoute({Key? key}) : super(key: key);

  @override
  // ignore: dead_code
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text("GFG Second Route"),
          backgroundColor: Colors.green,
        ),
        body: Center(
          child: ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Go back!'),
          ), // ElevatedButton
        ),
      ),
    );
  }
}

class listView extends StatelessWidget {
  const listView({Key? key}) : super(key: key);

  final List<int> numberList = const <int>[1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  @override
  // ignore: dead_code
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text("GFG Second Route"),
          backgroundColor: Colors.green,
        ),
        body:
        ListView(
          children: numberList.map((number){
            return Container(
              height: 250,
              decoration: BoxDecoration(
                color: Colors.greenAccent,
                border: Border.all(color: Colors.green)
              ),
              child: Center(
                child: Text(
                  '$number', style: const TextStyle(fontSize: 50),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class SecondScreen extends StatelessWidget{
  final String message;

  const SecondScreen(this.message, {Key? key}) : super(key: key);



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Second Screen'),
      ),
      body: Center(
        child:
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('$message'),
            OutlinedButton(
              child: const Text('Kembali'),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),

      ),
    );
  }
}

class FirstScreenFlutter2 extends StatelessWidget{
  const FirstScreenFlutter2({Key? key}) : super(key: key);

  final String message = 'Hello from First Screen!';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('First Screen'),
      ),
      body: Center(
        child: OutlinedButton(
          child: const Text('Pindah Screen'),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => SecondScreen(message)));
          },
        ),
      ),
    );
  }
}