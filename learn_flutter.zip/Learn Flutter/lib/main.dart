import 'package:flutter/material.dart';
import 'package:learn_flutter/detail_screen.dart';
import 'package:learn_flutter/flutter.dart';

void main() {
  runApp(const MyApp2());
}


class MyApp2 extends StatelessWidget {
  const MyApp2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const BiggerText(text: "Hallo"),// Panggil FirstScreen di sini

    );
  }
}

class MyApp3 extends StatelessWidget {
  const MyApp3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const FourthScreen(),// Panggil FirstScreen di sini

    );
  }
}

class FourthScreen extends StatelessWidget{
  const FourthScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Fourth Screen")
      ),
      body: Container(
        padding: const EdgeInsets.all(10),
        color: Colors.blue,
        child: const Text("Hi", style: TextStyle(fontSize: 40, color: Colors.white)),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Hello World!'),
        ),
        body:const Center(
          child: BiggerText(
            text: 'Hello!',
          ),
        )
      ),
    );
  }
}

class FirstScreen extends StatelessWidget{
  const FirstScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("First Screen"),
        actions: <Widget>[
          IconButton(
            icon: const Icon(
              Icons.search,
              color: Colors.white,
            ),
            onPressed: (){
            },
          )
        ],
        leading: IconButton(
          icon: const Icon(
            Icons.menu,
            color: Colors.white,
          ),
          onPressed: (){},
        ),
      ),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Container(
            decoration: const BoxDecoration(
              color: Colors.lightBlue,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black,
                  offset: Offset(1, 2),
                  blurRadius: 5,
                ),
              ],
            ),
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.all(10),
            child: const Text(
              "Hi",
              style: TextStyle(fontSize: 40, color: Colors.white),
            ),
          ),
          const Icon(Icons.share),
          const Icon(Icons.thumb_up),
          const Icon(Icons.thumb_down),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: (){},
      ),
    );
  }
}

class SecondScreen extends StatelessWidget{
  const SecondScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("First Screen"),
        actions: <Widget>[
          IconButton(
            icon: const Icon(
              Icons.search,
              color: Colors.white,
            ),
            onPressed: (){
            },
          )
        ],
        leading: IconButton(
          icon: const Icon(
            Icons.menu,
            color: Colors.white,
          ),
          onPressed: (){},
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Container(
            margin:const EdgeInsets.only(top:10),
            child: const Text("Farm House Lembang",
              style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold), textAlign: TextAlign.center,),
           ),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Column(
                  children: const <Widget>[
                    Icon(Icons.date_range),
                    SizedBox(height: 8.0),
                    Text("Open Everyday")
                  ],
                ),
                Column(
                  children: const <Widget>[
                    Icon(Icons.timelapse),
                    SizedBox(height: 8.0),
                    Text("09:00 - 20:00")
                  ],
                ),
                Column(
                  children: const <Widget>[
                    Icon(Icons.money),
                    SizedBox(height: 8.0),
                    Text("Rp. 25.000")
                  ],
                )
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16.0),
            child: const Center(
              child:Text("In publishing and graphic design, Lorem ipsum is a placeholder "
                  "text commonly used to demonstrate the visual form of a document or"
                  " a typeface without relying on meaningful content. Lorem ipsum may"
                  " be used as a placeholder before final copy is available",
                  style: TextStyle(fontSize: 14), textAlign: TextAlign.center),
            ) ,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: (){},
      ),
    );
  }
}

class _ThirdScreenState extends State<ThirdScreen> {
  String _name = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Third Screen'),
      ),
      body:Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextField(
                decoration: const InputDecoration(
                  hintText: 'Write your name here...',
                  labelText: 'Your Name',
                ),
                onChanged: (String value) {
                  setState(() {
                    _name = value;
                  });
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                child: const Text('Submit'),
                onPressed: () {
                  showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          content: Text('Hello, $_name'),
                        );
                      });
                },
              ),
            ],
          ),
        ),
      )
    );
  }
}


class ThirdScreen extends StatefulWidget{

  const ThirdScreen({Key? key}) : super(key: key);

  @override
  _ThirdScreenState createState() => _ThirdScreenState();
}

class Heading extends StatelessWidget{
  final String text;

  const Heading({Key? key, required this.text}) : super(key: key);

  @override
  Widget build(BuildContext context){
    return Text(
      text,
      style: const TextStyle(
        fontSize: 20.0,
        fontWeight: FontWeight.bold,
        color: Colors.black
      ),
    );
  }
}

class ContohStateful extends StatefulWidget {

  final String parameterWidget; // ini parameter widget

  const ContohStateful({Key? key, required this.parameterWidget}) : super(key: key);

  @override
  _ContohStatefulState createState() => _ContohStatefulState();
}

class _ContohStatefulState extends State<ContohStateful>{
   String _dataState = "Hi"; // ini state dari Widget ContohStateful

  @override
  Widget build(BuildContext context){
    // isi sebuah widget
    return Text(
      _dataState,
      style: const TextStyle(
          fontSize: 20.0,
          fontWeight: FontWeight.bold,
          color: Colors.blue
      ),
    );
  }
}

class BiggerText extends StatefulWidget {
  final String text;

  const BiggerText({Key? key, required this.text}) : super(key: key);

  @override
  _BiggerTextState createState() => _BiggerTextState();
}


class _BiggerTextState extends State<BiggerText> {
  double _textSize = 16.0;
  Color _color = Colors.white;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Text(widget.text, style: TextStyle(fontSize: _textSize, color: _color)),
        ElevatedButton(
          child: const Text("Perbesar"),
          onPressed: () {
            setState(() {
              _textSize = 32.0;
              _color = Colors.blue;
            });
          },
        )
      ],
    );
  }
}




