import 'package:flutter/material.dart';



class DetailScreen extends StatelessWidget{
  const DetailScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("First Screen"),
        actions: <Widget>[
          IconButton(
            icon: const Icon(
              Icons.search,
              color: Colors.white,
            ),
            onPressed: (){
            },
          )
        ],
        leading: IconButton(
          icon: const Icon(
            Icons.menu,
            color: Colors.white,
          ),
          onPressed: (){},
        ),
      ),
      body: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Image.asset('images/unsriflutter.png'),
          Container(
            margin:const EdgeInsets.only(top:10),
            child: const Text("Damri Universitas Sriwijaya",
              style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold), textAlign: TextAlign.center,),
          ),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Column(
                  children: const <Widget>[
                    Icon(Icons.date_range),
                    SizedBox(height: 8.0),
                    Text("Monday - Friday")
                  ],
                ),
                Column(
                  children: const <Widget>[
                    Icon(Icons.timelapse),
                    SizedBox(height: 8.0),
                    Text("08:00 - 14:00")
                  ],
                ),
                Column(
                  children: const <Widget>[
                    Icon(Icons.money),
                    SizedBox(height: 8.0),
                    Text("Rp. 10.000")
                  ],
                )
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16.0),
            child: const Center(
              child:Text("In publishing and graphic design, Lorem ipsum is a placeholder "
                  "text commonly used to demonstrate the visual form of a document or"
                  " a typeface without relying on meaningful content. Lorem ipsum may"
                  " be used as a placeholder before final copy is available",
                  style: TextStyle(fontSize: 14), textAlign: TextAlign.center),
            ) ,
          ),
          SizedBox(
            height: 150,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(4.0),
                  child:Image.network(
                      'https://media-cdn.tripadvisor.com/media/photo-s/0d/7c/59/70/farmhouse-lembang.jpg'),
                ),
                Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Image.network(
                      'https://media-cdn.tripadvisor.com/media/photo-w/13/f0/22/f6/photo3jpg.jpg'),
                ),
                Padding(
                  padding: const EdgeInsets.all(4.0),
                  child:  Image.network(
                      'https://media-cdn.tripadvisor.com/media/photo-m/1280/16/a9/33/43/liburan-di-farmhouse.jpg'),
                ),
              ],
            ),
          ),
        ],
      )
      ),
    );
  }
}