import 'package:flutter/material.dart';

void main() {
  runApp(const LatihanPertama());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text("Learn Flutter"),
        ),
        body:
        Padding(
          padding: const EdgeInsets.all(20),
          child:   Container(
            color: Colors.blue ,
            child: Center(
                child: Text("Hello", style: TextStyle(color: Colors.white),)
            ),
            width: 100,
            height: 100,
          ),
        ),
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          onPressed: (){},
        ),
      ),
    );
  }
}

class FirstScreen extends StatelessWidget{
  const FirstScreen({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text("Learn Flutter"),
        ),
        body: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children:const <Widget>[
            Icon(Icons.ice_skating),
            Icon(Icons.abc_sharp),
            Icon(Icons.access_alarm)
          ],
        ),
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          onPressed: (){},
        ),
      ),
    );
  }
}


class SecondScreen extends StatelessWidget{
  const SecondScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text("Learn Flutter"),
        ),
        body:Column(
          children: const <Widget>[
            Text("Selamat Datang!", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),),
            Text("Pengguna Baru")
          ],
        ),
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          onPressed: (){},
        ),
      ),
    );
  }
}

class LatihanPertama extends StatelessWidget{
  const LatihanPertama({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SafeArea(
        child:Scaffold(
          body:Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Image.network('https://media-cdn.tripadvisor.com/media/photo-s/0d/7c/59/70/farmhouse-lembang.jpg'),
              Container(
                margin:const EdgeInsets.only(top:10),
                child: const Text("Farm House Lembang",
                  style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold), textAlign: TextAlign.center),
              ),
              Container(
                margin: EdgeInsets.symmetric(vertical: 16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Column(
                      children:const <Widget>[
                        Icon(Icons.date_range),

                        Text("Open")
                      ],
                    ),
                    Column(
                      children:const <Widget>[
                        Icon(Icons.timelapse),
                        Text("08:00 - 12:00")
                      ],
                    ),
                    Column(
                      children:const <Widget>[
                        Icon(Icons.money),
                        Text("Rp.10.000")
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                child: const Center(
                  child:Text("In publishing and graphic design, Lorem ipsum is a placeholder "
                      "text commonly used to demonstrate the visual form of a document or"
                      " a typeface without relying on meaningful content. Lorem ipsum may"
                      " be used as a placeholder before final copy is available",
                      style: TextStyle(fontSize: 14), textAlign: TextAlign.center),
                ),
              ),
              SizedBox(
                height: 150,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(4),
                      child:  Image.network(
                          'https://media-cdn.tripadvisor.com/media/photo-s/0d/7c/59/70/farmhouse-lembang.jpg') ,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(4),
                      child:    Image.network(
                          'https://media-cdn.tripadvisor.com/media/photo-w/13/f0/22/f6/photo3jpg.jpg'),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(4),
                      child:   Image.network(
                          'https://media-cdn.tripadvisor.com/media/photo-m/1280/16/a9/33/43/liburan-di-farmhouse.jpg')
                    )
                  ],
                ) ,
              )
            ],
          ),
        ),
      )
    );
  }
}

