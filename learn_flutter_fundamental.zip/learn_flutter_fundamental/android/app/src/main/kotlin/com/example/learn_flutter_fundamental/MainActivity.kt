package com.example.learn_flutter_fundamental

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
